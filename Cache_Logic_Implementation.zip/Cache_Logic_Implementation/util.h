/* finds the highest 1 bit, and returns its position, else 0xFFFFFFFF */
unsigned int uint_log2(unsigned int w); 

/* return random int from 0..x-1 */
int randomint( int x );
